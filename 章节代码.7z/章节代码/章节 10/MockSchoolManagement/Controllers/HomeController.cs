﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MockSchoolManagement.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Hello from MVC";
        }
    }
}
